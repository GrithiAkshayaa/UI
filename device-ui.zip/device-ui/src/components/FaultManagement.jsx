import React from "react";

function FaultManagement() {
  return <h2>Fault Management Page</h2>;
}

export default FaultManagement;
