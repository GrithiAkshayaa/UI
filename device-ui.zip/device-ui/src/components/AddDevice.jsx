import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function AddDevice() {
  const [form, setForm] = useState({ ip: "", username: "", password: "", type: "" });
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    alert("Device added successfully");
    navigate("/login");
  };

  return (
    <div className="container">
      <h2>Add Device</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="IP Address" required onChange={(e) => setForm({ ...form, ip: e.target.value })} />
        <input placeholder="Username" required onChange={(e) => setForm({ ...form, username: e.target.value })} />
        <input type="password" placeholder="Password" required onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <select required onChange={(e) => setForm({ ...form, type: e.target.value })}>
          <option value="">Select Device Type</option>
          <option value="AMPLIFIER">AMPLIFIER</option>
          <option value="TRANSPONDER">TRANSPONDER</option>
          <option value="MUX">MUX</option>
        </select>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default AddDevice;
