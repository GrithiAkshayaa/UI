import React from "react";
import { useParams, useNavigate } from "react-router-dom";

function DeviceOptions() {
  const { deviceType } = useParams();
  const navigate = useNavigate();

  return (
    <div className="container">
      <h2>Device: {deviceType}</h2>
      <button onClick={() => navigate("/configuration")}>Configuration Management</button>
      <div></div>
      <button onClick={() => navigate("/performance")}>Performance Management</button>
      <button onClick={() => navigate("/fault")}>Fault Management</button>
    </div>
  );
}

export default DeviceOptions;
