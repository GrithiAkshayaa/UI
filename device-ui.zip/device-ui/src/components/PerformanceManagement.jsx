import React from "react";

function PerformanceManagement() {
  return <h2>Performance Management Page</h2>;
}

export default PerformanceManagement;
