import React from "react";

function ConfigurationManagement() {
  return <h2>Configuration Management Page</h2>;
}

export default ConfigurationManagement;
